<?php
namespace GQL;

trait ReturnTypeResolver {
    
    public function ReturnType_order ($root, $args, &$ctx) { return null; }

}
?>