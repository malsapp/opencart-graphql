<?php
namespace GQL;

trait RewardTypeResolver {
    
    public function RewardType_customer ($root, $args, &$ctx) { return null; }

}
?>