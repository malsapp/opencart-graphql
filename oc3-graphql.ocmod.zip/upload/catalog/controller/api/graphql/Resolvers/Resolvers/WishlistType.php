<?php
namespace GQL;

trait WishlistTypeResolver {
    
    public function WishlistType_customer ($root, $args, &$ctx) { return null; }

    public function WishlistType_product ($root, $args, &$ctx) { return null; }

}
?>