<?php
namespace GQL;

trait CategoryFilterGroupTypeResolver {
    
    public function CategoryFilterGroupType_filter ($root, $args, &$ctx) { return null; }

}
?>