# Usage

Clone `malsapp/gql2php` repo
.
from within `gql2php` use `index.js -f ../${Graphql-Schema directory}/scheme.gql -o ../${opencart controller directory}`

Then copy over the GragphQLController contents to your opencart controller directory.
