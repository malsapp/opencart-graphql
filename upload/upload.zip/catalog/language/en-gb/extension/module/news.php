<?php
// Heading 
$_['heading_title']    = 'Our News';
