<?php
// Heading
$_['heading_title']     = 'Frequently Asked Questions';

// Text
$_['text_faq']          = 'FAQs';
$_['text_error']        = 'FAQs not found!';
$_['text_empty']        = 'There are no faqs to list.';
$_['text_display']      = 'Display:';
$_['text_sort']         = 'Sort By:';
$_['text_default']      = 'Default';
$_['text_limit']        = 'Show:';
?>