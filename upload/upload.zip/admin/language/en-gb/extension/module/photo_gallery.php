<?php
// Heading
$_['heading_title']    = 'Photo Gallery';

$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Photo Gallery module!';
$_['text_edit']        = 'Edit Photo Gallery Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Photo Gallery module!';